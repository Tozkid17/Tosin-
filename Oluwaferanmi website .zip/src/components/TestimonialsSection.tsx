import React from 'react';
import { TESTIMONIALS_DATA, Testimonial } from '../data/beautyData';
import { Sparkles, Star, Quote } from 'lucide-react';

export const TestimonialsSection: React.FC = () => {
  return (
    <section id="testimonials" className="py-20 lg:py-28 relative bg-[#0b070d]">
      <div className="absolute top-1/2 left-0 w-96 h-96 rounded-full bg-pink-600/10 blur-[150px] pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-pink-950/60 border border-pink-500/30 text-pink-200 text-xs font-semibold tracking-widest uppercase">
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>CLIENT REVIEWS</span>
          </div>

          <h2 className="text-3xl sm:text-5xl font-cinzel font-bold text-white tracking-tight">
            Loved By <span className="gold-gradient-text">Queens Everywhere</span>
          </h2>

          <p className="text-pink-100/70 text-sm sm:text-base">
            Read genuine experiences from brides, models, and everyday royalty who trust Queen Oluwaferanmi with their glam.
          </p>
        </div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {TESTIMONIALS_DATA.map((item: Testimonial) => (
            <div 
              key={item.id}
              className="glass-card p-8 rounded-3xl border border-pink-500/20 flex flex-col justify-between relative group hover:border-amber-400/40 transition-all shadow-xl"
            >
              <div className="absolute top-6 right-6 text-pink-500/20 group-hover:text-amber-400/30 transition-colors">
                <Quote className="w-10 h-10" />
              </div>

              <div className="space-y-4 relative z-10">
                {/* Stars */}
                <div className="flex items-center gap-1 text-amber-400">
                  {[...Array(item.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-amber-400" />
                  ))}
                </div>

                <p className="text-sm text-pink-100/90 italic leading-relaxed">
                  &quot;{item.comment}&quot;
                </p>
              </div>

              <div className="pt-6 mt-6 border-t border-pink-950/60 flex items-center gap-4 relative z-10">
                <img 
                  src={item.image} 
                  alt={item.name} 
                  className="w-12 h-12 rounded-full object-cover border border-amber-400/40"
                />
                <div>
                  <h4 className="font-bold text-white text-sm">{item.name}</h4>
                  <div className="text-xs text-pink-300/80">{item.role}</div>
                  <div className="text-[10px] text-amber-300 font-semibold mt-0.5">{item.service}</div>
                </div>
              </div>

            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
