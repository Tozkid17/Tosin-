import React, { useState, useEffect } from 'react';
import { Crown, Phone, Calendar, Menu, X, Sparkles } from 'lucide-react';

interface NavbarProps {
  onOpenBooking: (serviceName?: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenBooking }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 40) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      isScrolled ? 'bg-[#0b070d]/90 backdrop-blur-md border-b border-pink-500/20 py-3 shadow-2xl shadow-pink-950/30' : 'bg-transparent py-5'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
        
        {/* Brand Logo */}
        <a href="#" className="flex items-center gap-2.5 group">
          <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-rose-500 via-pink-500 to-amber-400 p-[2px] shadow-lg shadow-pink-500/30 group-hover:scale-105 transition-transform">
            <div className="w-full h-full bg-[#0b070d] rounded-full flex items-center justify-center">
              <Crown className="w-5 h-5 text-amber-300 animate-pulse" />
            </div>
          </div>
          <div>
            <div className="font-cinzel font-bold text-lg sm:text-xl tracking-wider gold-gradient-text flex items-center gap-1.5">
              QUEEN <span className="font-light text-pink-200">OLUWAFERANMI</span>
            </div>
            <div className="text-[10px] tracking-[0.2em] text-pink-300/80 font-medium uppercase">
              Makeup Artist & Hairstylist
            </div>
          </div>
        </a>

        {/* Desktop Navigation Links */}
        <nav className="hidden md:flex items-center gap-8 text-sm font-medium">
          <a href="#services" className="text-pink-100 hover:text-amber-300 transition-colors">Services</a>
          <a href="#portfolio" className="text-pink-100 hover:text-amber-300 transition-colors">Portfolio</a>
          <a href="#about" className="text-pink-100 hover:text-amber-300 transition-colors">About Me</a>
          <a href="#testimonials" className="text-pink-100 hover:text-amber-300 transition-colors">Reviews</a>
          <a href="#faq" className="text-pink-100 hover:text-amber-300 transition-colors">FAQ</a>
        </nav>

        {/* Right Action / Contact */}
        <div className="hidden lg:flex items-center gap-4">
          <a 
            href="tel:09168876667" 
            className="flex items-center gap-2 text-xs font-semibold px-3.5 py-2 rounded-full border border-pink-500/30 bg-pink-950/30 text-pink-200 hover:bg-pink-900/50 hover:border-amber-400/50 transition-all"
          >
            <Phone className="w-3.5 h-3.5 text-amber-400" />
            <span>09168876667</span>
          </a>

          <button
            onClick={() => onOpenBooking()}
            className="relative group overflow-hidden rounded-full p-[1px] focus:outline-none"
          >
            <span className="absolute inset-0 bg-gradient-to-r from-amber-400 via-rose-500 to-pink-500 animate-spin-slow"></span>
            <span className="relative px-5 py-2 rounded-full bg-[#0b070d] text-pink-100 text-xs font-semibold tracking-wider flex items-center gap-2 group-hover:bg-opacity-80 transition-all">
              <Sparkles className="w-3.5 h-3.5 text-amber-300 animate-bounce" />
              BOOK NOW
            </span>
          </button>
        </div>

        {/* Mobile Menu Button */}
        <button 
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="md:hidden p-2 rounded-lg text-pink-200 hover:bg-pink-950/50 focus:outline-none"
          aria-label="Toggle Menu"
        >
          {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>

      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden absolute top-full left-0 right-0 bg-[#0b070d]/95 backdrop-blur-xl border-b border-pink-500/30 px-6 py-6 space-y-4 shadow-2xl animate-fadeIn">
          <nav className="flex flex-col space-y-3 font-medium">
            <a 
              href="#services" 
              onClick={() => setMobileMenuOpen(false)}
              className="py-2 text-pink-100 hover:text-amber-300 border-b border-pink-950/60"
            >
              Services & Prices
            </a>
            <a 
              href="#portfolio" 
              onClick={() => setMobileMenuOpen(false)}
              className="py-2 text-pink-100 hover:text-amber-300 border-b border-pink-950/60"
            >
              Portfolio Gallery
            </a>
            <a 
              href="#about" 
              onClick={() => setMobileMenuOpen(false)}
              className="py-2 text-pink-100 hover:text-amber-300 border-b border-pink-950/60"
            >
              About Queen Oluwaferanmi
            </a>
            <a 
              href="#testimonials" 
              onClick={() => setMobileMenuOpen(false)}
              className="py-2 text-pink-100 hover:text-amber-300 border-b border-pink-950/60"
            >
              Client Reviews
            </a>
            <a 
              href="#faq" 
              onClick={() => setMobileMenuOpen(false)}
              className="py-2 text-pink-100 hover:text-amber-300"
            >
              FAQ
            </a>
          </nav>

          <div className="pt-4 flex flex-col gap-3">
            <a 
              href="tel:09168876667" 
              className="flex items-center justify-center gap-2 py-3 rounded-xl bg-pink-950/40 border border-pink-500/30 text-pink-200 text-sm font-bold"
            >
              <Phone className="w-4 h-4 text-amber-400" />
              <span>Call / WhatsApp: 09168876667</span>
            </a>

            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenBooking();
              }}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-rose-500 via-pink-500 to-amber-400 text-[#0b070d] font-bold text-sm tracking-wider shadow-lg shadow-pink-500/30 flex items-center justify-center gap-2"
            >
              <Calendar className="w-4 h-4" />
              BOOK AN APPOINTMENT NOW
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
