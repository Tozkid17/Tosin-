import React, { useState } from 'react';
import { SERVICES_DATA, ServiceItem } from '../data/beautyData';
import { Scissors, Paintbrush, Sparkles, Clock, ArrowRight } from 'lucide-react';

interface ServicesSectionProps {
  onOpenBooking: (serviceName?: string) => void;
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({ onOpenBooking }) => {
  const [activeTab, setActiveTab] = useState<'all' | 'hair' | 'makeup' | 'combo'>('all');

  const filteredServices = activeTab === 'all' 
    ? SERVICES_DATA 
    : SERVICES_DATA.filter(service => service.category === activeTab);

  return (
    <section id="services" className="py-20 lg:py-28 relative bg-[#0d0810]">
      {/* Background Ambience */}
      <div className="absolute top-1/2 left-0 w-96 h-96 rounded-full bg-pink-600/10 blur-[140px] pointer-events-none"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-14">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-pink-950/60 border border-pink-500/30 text-pink-200 text-xs font-semibold tracking-widest uppercase">
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>WHAT I DO</span>
          </div>

          <h2 className="text-3xl sm:text-5xl font-cinzel font-bold text-white tracking-tight">
            Professional <span className="gold-gradient-text">Artistry & Styling</span>
          </h2>

          <p className="text-pink-100/70 text-sm sm:text-base">
            From seamless lace installations to red-carpet bridal makeovers. Experience expert care crafted to enhance your natural royalty.
          </p>

          {/* Filter Tabs */}
          <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-3 pt-6">
            <button
              onClick={() => setActiveTab('all')}
              className={`px-5 py-2.5 rounded-full text-xs font-bold tracking-wider transition-all ${
                activeTab === 'all'
                  ? 'bg-gradient-to-r from-rose-500 to-amber-500 text-[#0b070d] shadow-lg shadow-pink-500/30'
                  : 'glass-card text-pink-200 hover:border-pink-400'
              }`}
            >
              All Services
            </button>
            <button
              onClick={() => setActiveTab('hair')}
              className={`px-5 py-2.5 rounded-full text-xs font-bold tracking-wider transition-all flex items-center gap-2 ${
                activeTab === 'hair'
                  ? 'bg-gradient-to-r from-rose-500 to-amber-500 text-[#0b070d] shadow-lg shadow-pink-500/30'
                  : 'glass-card text-pink-200 hover:border-pink-400'
              }`}
            >
              <Scissors className="w-3.5 h-3.5" />
              Hairstylist
            </button>
            <button
              onClick={() => setActiveTab('makeup')}
              className={`px-5 py-2.5 rounded-full text-xs font-bold tracking-wider transition-all flex items-center gap-2 ${
                activeTab === 'makeup'
                  ? 'bg-gradient-to-r from-rose-500 to-amber-500 text-[#0b070d] shadow-lg shadow-pink-500/30'
                  : 'glass-card text-pink-200 hover:border-pink-400'
              }`}
            >
              <Paintbrush className="w-3.5 h-3.5" />
              Makeup Artist
            </button>
            <button
              onClick={() => setActiveTab('combo')}
              className={`px-5 py-2.5 rounded-full text-xs font-bold tracking-wider transition-all flex items-center gap-2 ${
                activeTab === 'combo'
                  ? 'bg-gradient-to-r from-rose-500 to-amber-500 text-[#0b070d] shadow-lg shadow-pink-500/30'
                  : 'glass-card text-pink-200 hover:border-pink-400'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              VIP Combo
            </button>
          </div>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredServices.map((service: ServiceItem) => (
            <div 
              key={service.id}
              className="glass-card glass-card-hover rounded-3xl overflow-hidden flex flex-col justify-between group relative border border-pink-500/20"
            >
              {service.popular && (
                <div className="absolute top-4 right-4 z-20 bg-gradient-to-r from-amber-400 to-rose-500 text-[#0b070d] text-[10px] font-black uppercase tracking-widest px-3 py-1 rounded-full shadow-lg">
                  Most Popular
                </div>
              )}

              <div>
                {/* Service Image */}
                <div className="relative h-56 overflow-hidden">
                  <img 
                    src={service.image} 
                    alt={service.title} 
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#140c16] via-transparent to-transparent"></div>
                  
                  {/* Category Pill */}
                  <div className="absolute bottom-4 left-4 bg-[#0b070d]/80 backdrop-blur-md px-3 py-1 rounded-full text-[10px] font-semibold text-pink-300 uppercase tracking-widest flex items-center gap-1">
                    {service.category === 'hair' && <Scissors className="w-3 h-3 text-amber-300" />}
                    {service.category === 'makeup' && <Paintbrush className="w-3 h-3 text-pink-400" />}
                    {service.category === 'combo' && <Sparkles className="w-3 h-3 text-amber-300" />}
                    <span>{service.category === 'combo' ? 'VIP Combo' : service.category}</span>
                  </div>
                </div>

                {/* Content */}
                <div className="p-6 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xl font-cinzel font-bold text-amber-300">
                      {service.price}
                    </span>
                    <span className="text-xs text-pink-300/80 flex items-center gap-1 font-medium">
                      <Clock className="w-3 h-3" />
                      {service.duration}
                    </span>
                  </div>

                  <h3 className="text-lg font-bold text-white group-hover:text-pink-300 transition-colors">
                    {service.title}
                  </h3>

                  <p className="text-sm text-pink-100/70 leading-relaxed">
                    {service.description}
                  </p>
                </div>
              </div>

              {/* Action Button */}
              <div className="p-6 pt-0">
                <button
                  onClick={() => onOpenBooking(service.title)}
                  className="w-full py-3 rounded-xl bg-pink-950/60 hover:bg-gradient-to-r hover:from-rose-500 hover:to-amber-500 text-pink-200 hover:text-[#0b070d] text-xs font-bold tracking-wider border border-pink-500/30 transition-all flex items-center justify-center gap-2 group/btn shadow-md"
                >
                  <span>BOOK THIS SERVICE</span>
                  <ArrowRight className="w-4 h-4 group-hover/btn:translate-x-1 transition-transform" />
                </button>
              </div>

            </div>
          ))}
        </div>

        {/* Bottom Banner */}
        <div className="mt-16 glass-card p-8 rounded-3xl border border-pink-500/30 flex flex-col md:flex-row items-center justify-between gap-6 text-center md:text-left shadow-2xl">
          <div className="space-y-2">
            <h4 className="font-cinzel text-xl sm:text-2xl font-bold text-white">
              Need a Custom VIP Package for an Event?
            </h4>
            <p className="text-sm text-pink-100/70 max-w-2xl">
              We cater to destination weddings, music videos, movie sets, and exclusive red-carpet appearances. Let us curate your look from head to toe.
            </p>
          </div>

          <button
            onClick={() => onOpenBooking('Custom VIP Package')}
            className="px-8 py-3.5 rounded-full bg-gradient-to-r from-amber-400 via-rose-500 to-pink-500 text-[#0b070d] font-bold text-xs tracking-wider shadow-lg shadow-pink-500/30 shrink-0 hover:scale-105 transition-transform"
          >
            REQUEST CUSTOM QUOTE
          </button>
        </div>

      </div>
    </section>
  );
};
