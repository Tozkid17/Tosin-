import React from 'react';
import { Crown, Phone, MessageCircle, MapPin, Sparkles, Heart, Globe } from 'lucide-react';

interface FooterProps {
  onOpenBooking: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenBooking }) => {
  return (
    <footer className="bg-[#08050a] border-t border-pink-500/20 pt-16 pb-12 relative overflow-hidden">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-3/4 h-[1px] bg-gradient-to-r from-transparent via-pink-500/50 to-transparent"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 pb-12 border-b border-pink-950/80">
          
          {/* Brand Info */}
          <div className="space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-rose-500 via-pink-500 to-amber-400 p-[2px]">
                <div className="w-full h-full bg-[#0b070d] rounded-full flex items-center justify-center">
                  <Crown className="w-5 h-5 text-amber-300" />
                </div>
              </div>
              <div>
                <div className="font-cinzel font-bold text-lg tracking-wider gold-gradient-text">
                  QUEEN OLUWAFERANMI
                </div>
                <div className="text-[10px] tracking-widest text-pink-300 uppercase">
                  Makeup Artist & Hairstylist
                </div>
              </div>
            </div>

            <p className="text-xs text-pink-100/70 leading-relaxed">
              Beauty isn&apos;t just what I do. It&apos;s my calling. Enhancing beauty and empowering confidence, one queen at a time.
            </p>

            <div className="font-script text-2xl text-amber-300">
              Let&apos;s bring out the best in you ♡
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h4 className="font-cinzel font-bold text-white text-sm uppercase tracking-wider">Quick Navigation</h4>
            <ul className="space-y-2 text-xs font-medium text-pink-100/80">
              <li><a href="#services" className="hover:text-amber-300 transition-colors">Services & Pricing</a></li>
              <li><a href="#portfolio" className="hover:text-amber-300 transition-colors">Glam Portfolio</a></li>
              <li><a href="#about" className="hover:text-amber-300 transition-colors">About Queen Oluwaferanmi</a></li>
              <li><a href="#testimonials" className="hover:text-amber-300 transition-colors">Client Reviews</a></li>
              <li><a href="#faq" className="hover:text-amber-300 transition-colors">Frequently Asked Questions</a></li>
            </ul>
          </div>

          {/* Services Quicklist */}
          <div className="space-y-4">
            <h4 className="font-cinzel font-bold text-white text-sm uppercase tracking-wider">Expertise</h4>
            <ul className="space-y-2 text-xs font-medium text-pink-100/80">
              <li>Bridal Makeup & Engagement Glam</li>
              <li>Wig Installation & Lace Melting</li>
              <li>Photoshoot & Editorial Styling</li>
              <li>Braids & Protective Styles</li>
              <li>VIP Studio & Home Service</li>
            </ul>
          </div>

          {/* Contact & Booking */}
          <div className="space-y-4">
            <h4 className="font-cinzel font-bold text-white text-sm uppercase tracking-wider">Direct Contact</h4>
            
            <div className="space-y-3 text-xs text-pink-100/80">
              <a href="tel:09168876667" className="flex items-center gap-2.5 hover:text-amber-300 transition-colors">
                <div className="w-8 h-8 rounded-full bg-pink-950/60 border border-pink-500/30 flex items-center justify-center text-amber-300">
                  <Phone className="w-3.5 h-3.5" />
                </div>
                <span className="font-bold text-sm">09168876667</span>
              </a>

              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-full bg-pink-950/60 border border-pink-500/30 flex items-center justify-center text-amber-300">
                  <MapPin className="w-3.5 h-3.5" />
                </div>
                <span>Lagos & Nationwide (VIP House Calls)</span>
              </div>
            </div>

            <button
              onClick={onOpenBooking}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-400 via-rose-500 to-pink-500 text-[#0b070d] font-bold text-xs tracking-wider shadow-lg shadow-pink-500/30 flex items-center justify-center gap-2 hover:scale-105 transition-transform"
            >
              <Sparkles className="w-3.5 h-3.5" />
              BOOK APPOINTMENT NOW
            </button>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-pink-300/70">
          <div>
            &copy; {new Date().getFullYear()} Queen Oluwaferanmi Beauty. All rights reserved.
          </div>

          <div className="flex items-center gap-6">
            <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="hover:text-amber-300 transition-colors flex items-center gap-1.5">
              <Globe className="w-4 h-4" />
              <span>Socials & Community</span>
            </a>
            <a href="https://wa.me/2349168876667" target="_blank" rel="noopener noreferrer" className="hover:text-amber-300 transition-colors flex items-center gap-1.5">
              <MessageCircle className="w-4 h-4" />
              <span>WhatsApp Direct</span>
            </a>
          </div>

          <div className="flex items-center gap-1">
            <span>Crafted with</span>
            <Heart className="w-3 h-3 text-rose-500 fill-rose-500" />
            <span>for Queens</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
