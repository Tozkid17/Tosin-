import React, { useState } from 'react';
import { PORTFOLIO_DATA, PortfolioItem } from '../data/beautyData';
import { Sparkles, Eye, X, Tag } from 'lucide-react';

interface PortfolioSectionProps {
  onOpenBooking: (serviceName?: string) => void;
}

export const PortfolioSection: React.FC<PortfolioSectionProps> = ({ onOpenBooking }) => {
  const [activeFilter, setActiveFilter] = useState<'all' | 'bridal' | 'photoshoot' | 'hair' | 'soft-glam'>('all');
  const [selectedImage, setSelectedImage] = useState<PortfolioItem | null>(null);

  const filteredPortfolio = activeFilter === 'all'
    ? PORTFOLIO_DATA
    : PORTFOLIO_DATA.filter(item => item.category === activeFilter);

  return (
    <section id="portfolio" className="py-20 lg:py-28 relative bg-[#0b070d]">
      <div className="absolute top-1/3 right-0 w-96 h-96 rounded-full bg-amber-500/10 blur-[150px] pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-14">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-pink-950/60 border border-pink-500/30 text-pink-200 text-xs font-semibold tracking-widest uppercase">
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>GLAM GALLERY</span>
          </div>

          <h2 className="text-3xl sm:text-5xl font-cinzel font-bold text-white tracking-tight">
            Our Royal <span className="gold-gradient-text">Masterpieces</span>
          </h2>

          <p className="text-pink-100/70 text-sm sm:text-base">
            Explore breathtaking transformations, flawless lace melts, and striking makeup artistry curated by Queen Oluwaferanmi.
          </p>

          {/* Filter Tabs */}
          <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-3 pt-6">
            <button
              onClick={() => setActiveFilter('all')}
              className={`px-5 py-2.5 rounded-full text-xs font-bold tracking-wider transition-all ${
                activeFilter === 'all'
                  ? 'bg-gradient-to-r from-rose-500 to-amber-500 text-[#0b070d] shadow-lg shadow-pink-500/30'
                  : 'glass-card text-pink-200 hover:border-pink-400'
              }`}
            >
              All Works
            </button>
            <button
              onClick={() => setActiveFilter('bridal')}
              className={`px-5 py-2.5 rounded-full text-xs font-bold tracking-wider transition-all ${
                activeFilter === 'bridal'
                  ? 'bg-gradient-to-r from-rose-500 to-amber-500 text-[#0b070d] shadow-lg shadow-pink-500/30'
                  : 'glass-card text-pink-200 hover:border-pink-400'
              }`}
            >
              Bridal Glam
            </button>
            <button
              onClick={() => setActiveFilter('hair')}
              className={`px-5 py-2.5 rounded-full text-xs font-bold tracking-wider transition-all ${
                activeFilter === 'hair'
                  ? 'bg-gradient-to-r from-rose-500 to-amber-500 text-[#0b070d] shadow-lg shadow-pink-500/30'
                  : 'glass-card text-pink-200 hover:border-pink-400'
              }`}
            >
              Hair & Wigs
            </button>
            <button
              onClick={() => setActiveFilter('photoshoot')}
              className={`px-5 py-2.5 rounded-full text-xs font-bold tracking-wider transition-all ${
                activeFilter === 'photoshoot'
                  ? 'bg-gradient-to-r from-rose-500 to-amber-500 text-[#0b070d] shadow-lg shadow-pink-500/30'
                  : 'glass-card text-pink-200 hover:border-pink-400'
              }`}
            >
              Photoshoot Glam
            </button>
            <button
              onClick={() => setActiveFilter('soft-glam')}
              className={`px-5 py-2.5 rounded-full text-xs font-bold tracking-wider transition-all ${
                activeFilter === 'soft-glam'
                  ? 'bg-gradient-to-r from-rose-500 to-amber-500 text-[#0b070d] shadow-lg shadow-pink-500/30'
                  : 'glass-card text-pink-200 hover:border-pink-400'
              }`}
            >
              Soft & Natural
            </button>
          </div>
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredPortfolio.map((item: PortfolioItem) => (
            <div 
              key={item.id}
              onClick={() => setSelectedImage(item)}
              className="group relative h-80 rounded-3xl overflow-hidden glass-card cursor-pointer border border-pink-500/20 shadow-xl"
            >
              <img 
                src={item.image} 
                alt={item.title} 
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0b070d] via-[#0b070d]/30 to-transparent opacity-80 group-hover:opacity-90 transition-opacity"></div>

              {/* Hover overlay content */}
              <div className="absolute inset-0 p-6 flex flex-col justify-end translate-y-4 group-hover:translate-y-0 transition-transform">
                <div className="flex flex-wrap gap-1.5 mb-2">
                  {item.tags.map((tag, idx) => (
                    <span key={idx} className="px-2.5 py-0.5 rounded-full bg-pink-950/80 border border-pink-500/30 text-[10px] font-bold text-pink-200 uppercase">
                      {tag}
                    </span>
                  ))}
                </div>

                <h3 className="text-xl font-cinzel font-bold text-white mb-1">
                  {item.title}
                </h3>
                
                <p className="text-xs text-pink-200/80 line-clamp-2 mb-3">
                  {item.description}
                </p>

                <div className="flex items-center gap-2 text-xs font-bold text-amber-300">
                  <Eye className="w-4 h-4" />
                  <span>View Full Transformation</span>
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>

      {/* Lightbox Modal */}
      {selectedImage && (
        <div className="fixed inset-0 z-50 bg-[#0b070d]/90 backdrop-blur-xl flex items-center justify-center p-4 sm:p-6 animate-fadeIn">
          <div className="relative max-w-4xl w-full glass-card rounded-3xl overflow-hidden border border-pink-500/30 shadow-2xl grid grid-cols-1 md:grid-cols-2">
            
            {/* Close Button */}
            <button
              onClick={() => setSelectedImage(null)}
              className="absolute top-4 right-4 z-20 w-10 h-10 rounded-full bg-[#0b070d]/80 border border-pink-500/40 flex items-center justify-center text-pink-200 hover:text-amber-300 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Modal Image */}
            <div className="relative h-72 md:h-full min-h-[350px]">
              <img 
                src={selectedImage.image} 
                alt={selectedImage.title} 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0b070d] md:hidden"></div>
            </div>

            {/* Modal Info */}
            <div className="p-8 flex flex-col justify-between space-y-6">
              <div className="space-y-4">
                <div className="flex flex-wrap gap-1.5">
                  {selectedImage.tags.map((tag, idx) => (
                    <span key={idx} className="px-3 py-1 rounded-full bg-pink-950/80 border border-pink-500/30 text-xs font-bold text-amber-300 uppercase flex items-center gap-1">
                      <Tag className="w-3 h-3" />
                      {tag}
                    </span>
                  ))}
                </div>

                <h3 className="text-2xl sm:text-3xl font-cinzel font-bold text-white">
                  {selectedImage.title}
                </h3>

                <p className="text-sm text-pink-100/80 leading-relaxed">
                  {selectedImage.description}
                </p>

                <div className="p-4 rounded-2xl bg-pink-950/40 border border-pink-500/20 space-y-2">
                  <div className="text-xs font-bold text-pink-300 uppercase tracking-wider">Transformation Details</div>
                  <ul className="text-xs text-pink-100/70 space-y-1.5 list-disc list-inside">
                    <li>Custom skin prep & luxury long-wear foundation</li>
                    <li>HD lace melting & precision hairline styling</li>
                    <li>Professional lighting & camera-ready finish</li>
                  </ul>
                </div>
              </div>

              <button
                onClick={() => {
                  const serviceTitle = selectedImage.title;
                  setSelectedImage(null);
                  onOpenBooking(serviceTitle);
                }}
                className="w-full py-3.5 rounded-xl bg-gradient-to-r from-amber-400 via-rose-500 to-pink-500 text-[#0b070d] font-bold text-xs tracking-wider shadow-lg shadow-pink-500/30 hover:scale-105 transition-transform"
              >
                BOOK A SIMILAR LOOK
              </button>
            </div>

          </div>
        </div>
      )}

    </section>
  );
};
