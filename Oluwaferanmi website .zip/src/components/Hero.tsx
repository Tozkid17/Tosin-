import React from 'react';
import { Crown, Sparkles, Phone, ShieldCheck, Star, Heart, CheckCircle2, Scissors, Paintbrush } from 'lucide-react';

interface HeroProps {
  onOpenBooking: (service?: string) => void;
}

export const Hero: React.FC<HeroProps> = ({ onOpenBooking }) => {
  return (
    <section className="relative min-h-screen pt-28 pb-16 lg:pt-36 lg:pb-24 overflow-hidden flex items-center">
      {/* Background Glows & Ambience */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] lg:w-[700px] lg:h-[700px] rounded-full bg-gradient-to-tr from-pink-600/20 via-rose-500/30 to-amber-400/20 blur-[120px] pointer-events-none"></div>
      <div className="absolute bottom-10 left-10 w-72 h-72 rounded-full bg-purple-600/10 blur-[100px] pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left Column: Text & Flyer Copy */}
          <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
            
            {/* Top Cursive Quote */}
            <div className="space-y-1">
              <p className="font-script text-3xl sm:text-4xl lg:text-5xl text-pink-300 drop-shadow-[0_0_15px_rgba(244,114,182,0.5)]">
                Beauty isn&apos;t just what I do.
              </p>
              <p className="font-script text-3xl sm:text-4xl lg:text-5xl text-amber-300 italic">
                It&apos;s my calling. <span className="text-pink-400 text-2xl">♡</span>
              </p>
            </div>

            {/* Main Title with Crown */}
            <div className="space-y-2">
              <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-pink-950/60 border border-pink-500/30 text-pink-200 text-xs font-semibold tracking-widest uppercase">
                <Crown className="w-4 h-4 text-amber-300 animate-pulse" />
                <span>MASTER ARTISTRY & STYLING</span>
              </div>
              
              <h1 className="text-4xl sm:text-6xl lg:text-7xl font-cinzel font-black tracking-tight leading-none text-white">
                I AM <br />
                <span className="gold-gradient-text drop-shadow-[0_0_30px_rgba(251,191,36,0.3)]">
                  QUEEN
                </span> <br />
                <span className="font-script font-normal text-3xl sm:text-5xl lg:text-6xl text-pink-300 capitalize tracking-normal">
                  Oluwaferanmi
                </span>
              </h1>
            </div>

            {/* Profession Bar */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-4 text-xs sm:text-sm font-bold tracking-widest text-pink-200/90 py-2">
              <span className="flex items-center gap-1.5 bg-pink-900/30 px-3 py-1.5 rounded-md border border-pink-500/20">
                <Paintbrush className="w-4 h-4 text-pink-400" />
                MAKEUP ARTIST
              </span>
              <span className="text-amber-400 font-bold">|</span>
              <span className="flex items-center gap-1.5 bg-pink-900/30 px-3 py-1.5 rounded-md border border-pink-500/20">
                <Scissors className="w-4 h-4 text-amber-300" />
                HAIRSTYLIST
              </span>
            </div>

            {/* Sub Tagline */}
            <p className="text-base sm:text-lg text-pink-100/80 font-medium max-w-xl mx-auto lg:mx-0">
              Enhancing beauty. Empowering confidence. <span className="text-amber-300 font-semibold">Beauty. Confidence. You. All in one place.</span>
            </p>

            {/* Action Buttons & Phone */}
            <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4 pt-2">
              <button
                onClick={() => onOpenBooking()}
                className="w-full sm:w-auto px-8 py-4 rounded-full bg-gradient-to-r from-amber-400 via-rose-500 to-pink-500 text-[#0b070d] font-bold text-sm tracking-wider shadow-xl shadow-pink-500/30 hover:scale-105 transition-transform flex items-center justify-center gap-3"
              >
                <Sparkles className="w-4 h-4" />
                BOOK AN APPOINTMENT
              </button>

              <a
                href="tel:09168876667"
                className="w-full sm:w-auto px-6 py-4 rounded-full glass-card hover:border-amber-400/50 text-pink-100 text-sm font-semibold flex items-center justify-center gap-3 transition-all"
              >
                <div className="w-7 h-7 rounded-full bg-amber-400/20 flex items-center justify-center">
                  <Phone className="w-3.5 h-3.5 text-amber-300" />
                </div>
                <span>09168876667</span>
              </a>
            </div>

            {/* Bottom 3 Pillars matching flyer */}
            <div className="grid grid-cols-3 gap-3 pt-6 border-t border-pink-900/40 text-center lg:text-left">
              <div className="space-y-1">
                <div className="flex items-center justify-center lg:justify-start gap-1.5 text-amber-300 text-xs font-bold uppercase tracking-wider">
                  <ShieldCheck className="w-4 h-4 shrink-0" />
                  <span>Professional</span>
                </div>
                <p className="text-[11px] text-pink-200/70">Immaculate Service</p>
              </div>

              <div className="space-y-1">
                <div className="flex items-center justify-center lg:justify-start gap-1.5 text-amber-300 text-xs font-bold uppercase tracking-wider">
                  <Star className="w-4 h-4 shrink-0" />
                  <span>Quality</span>
                </div>
                <p className="text-[11px] text-pink-200/70">Premium Products</p>
              </div>

              <div className="space-y-1">
                <div className="flex items-center justify-center lg:justify-start gap-1.5 text-amber-300 text-xs font-bold uppercase tracking-wider">
                  <Heart className="w-4 h-4 shrink-0" />
                  <span>Satisfaction</span>
                </div>
                <p className="text-[11px] text-pink-200/70">100% Guaranteed</p>
              </div>
            </div>

          </div>

          {/* Right Column: Visual Composition inspired by flyer */}
          <div className="lg:col-span-5 relative flex justify-center">
            
            {/* Glowing Backdrop Circle */}
            <div className="absolute inset-0 bg-gradient-to-tr from-pink-500/20 to-amber-500/30 rounded-3xl blur-2xl transform rotate-3"></div>
            
            <div className="relative w-full max-w-md">
              
              {/* Main Image Container */}
              <div className="relative rounded-3xl overflow-hidden glass-card p-3 shadow-2xl shadow-pink-950/80 border border-pink-500/30">
                <div className="relative h-[480px] sm:h-[540px] rounded-2xl overflow-hidden group">
                  <img 
                    src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=800" 
                    alt="Queen Oluwaferanmi Makeup Artist & Hairstylist" 
                    className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-700"
                  />
                  
                  {/* Gradient Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0b070d] via-[#0b070d]/20 to-transparent"></div>

                  {/* Floating Badge */}
                  <div className="absolute top-4 right-4 bg-[#0b070d]/80 backdrop-blur-md px-3.5 py-2 rounded-full border border-amber-400/40 flex items-center gap-2 shadow-lg">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
                    <span className="text-xs font-bold text-amber-300">Open for Bookings</span>
                  </div>

                  {/* Bottom Image Caption */}
                  <div className="absolute bottom-4 left-4 right-4 p-4 rounded-xl bg-[#0b070d]/75 backdrop-blur-md border border-pink-500/20 space-y-1">
                    <div className="text-xs font-bold tracking-wider text-pink-300 uppercase flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                      Signature Queen Transformation
                    </div>
                    <p className="text-xs text-pink-100/80 italic">
                      &quot;Let&apos;s bring out the best in you ♡&quot;
                    </p>
                  </div>
                </div>
              </div>

              {/* Floating Stat Card Left */}
              <div className="absolute -bottom-6 -left-6 glass-card p-4 rounded-2xl shadow-xl border border-pink-500/30 flex items-center gap-3 animate-float hidden sm:flex">
                <div className="w-12 h-12 rounded-xl bg-amber-400/20 flex items-center justify-center shrink-0">
                  <Crown className="w-6 h-6 text-amber-300" />
                </div>
                <div>
                  <div className="text-xs text-pink-300 font-medium">Over 1,200+</div>
                  <div className="text-sm font-bold text-white font-cinzel">Queens Styled</div>
                </div>
              </div>

              {/* Floating Stat Card Right */}
              <div className="absolute -top-6 -right-6 glass-card p-3.5 rounded-2xl shadow-xl border border-pink-500/30 flex items-center gap-3 animate-float hidden sm:flex" style={{ animationDelay: '2s' }}>
                <div className="w-10 h-10 rounded-xl bg-pink-500/20 flex items-center justify-center shrink-0">
                  <CheckCircle2 className="w-5 h-5 text-pink-400" />
                </div>
                <div>
                  <div className="text-[10px] text-pink-300 font-medium">Client Rating</div>
                  <div className="text-xs font-bold text-white flex items-center gap-1">
                    <span>5.0</span>
                    <span className="text-amber-400">★★★★★</span>
                  </div>
                </div>
              </div>

            </div>

          </div>

        </div>
      </div>
    </section>
  );
};
