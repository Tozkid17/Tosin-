import React from 'react';
import { Crown, Sparkles, ShieldCheck, Star, Heart, CheckCircle2 } from 'lucide-react';

export const AboutSection: React.FC = () => {
  return (
    <section id="about" className="py-20 lg:py-28 relative bg-[#0d0810] overflow-hidden">
      {/* Ambience */}
      <div className="absolute top-1/2 left-1/4 w-96 h-96 rounded-full bg-pink-600/10 blur-[150px] pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          
          {/* Left Visual: Queen Portrait */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-md">
              <div className="absolute inset-0 bg-gradient-to-tr from-amber-500/20 to-pink-500/30 rounded-3xl blur-2xl"></div>
              
              <div className="relative glass-card p-3 rounded-3xl border border-pink-500/30 shadow-2xl">
                <div className="relative h-[450px] sm:h-[500px] rounded-2xl overflow-hidden group">
                  <img 
                    src="https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&q=80&w=800" 
                    alt="Queen Oluwaferanmi" 
                    className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0b070d] via-transparent to-transparent"></div>
                  
                  <div className="absolute bottom-6 left-6 right-6 p-4 rounded-xl bg-[#0b070d]/80 backdrop-blur-md border border-amber-400/30 space-y-1">
                    <div className="font-cinzel font-bold text-amber-300 text-sm">Queen Oluwaferanmi</div>
                    <p className="text-xs text-pink-200">Lead Makeup Artist & Hairstylist</p>
                  </div>
                </div>
              </div>

              {/* Floating Badge */}
              <div className="absolute -bottom-6 -right-6 glass-card p-4 rounded-2xl border border-pink-500/30 shadow-xl hidden sm:flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-amber-400 to-rose-500 flex items-center justify-center text-[#0b070d]">
                  <Crown className="w-6 h-6" />
                </div>
                <div>
                  <div className="text-xs font-bold text-white">Certified Expert</div>
                  <div className="text-[10px] text-pink-300">Over 6+ Years Experience</div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Content */}
          <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
            
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-pink-950/60 border border-pink-500/30 text-pink-200 text-xs font-semibold tracking-widest uppercase">
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              <span>THE QUEEN&apos;S PHILOSOPHY</span>
            </div>

            <h2 className="text-3xl sm:text-5xl font-cinzel font-bold text-white tracking-tight">
              Beauty isn&apos;t just what I do. <br />
              <span className="gold-gradient-text font-script text-4xl sm:text-6xl capitalize tracking-normal font-normal">
                It&apos;s my calling.
              </span>
            </h2>

            <p className="text-pink-100/80 text-base leading-relaxed">
              Welcome to the ultimate sanctuary of beauty and confidence. For years, Queen Oluwaferanmi has dedicated her passion, precision, and artistic vision to redefining luxury makeup and hair styling. Every brush stroke and lace installation is tailored to amplify your unique royal essence.
            </p>

            <p className="text-pink-100/70 text-sm leading-relaxed">
              Whether you are preparing for your traditional wedding, walking down the white wedding aisle, stepping onto a red carpet, or craving an everyday glam boost—our studio delivers perfection without compromise.
            </p>

            {/* Core Values Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4">
              <div className="glass-card p-4 rounded-2xl border border-pink-500/20 space-y-2 text-center lg:text-left">
                <div className="w-10 h-10 rounded-xl bg-amber-400/20 flex items-center justify-center mx-auto lg:mx-0">
                  <ShieldCheck className="w-5 h-5 text-amber-300" />
                </div>
                <h4 className="font-bold text-white text-sm">Professional Service</h4>
                <p className="text-xs text-pink-100/70">Punctual, hygienic, and attentive to every detail.</p>
              </div>

              <div className="glass-card p-4 rounded-2xl border border-pink-500/20 space-y-2 text-center lg:text-left">
                <div className="w-10 h-10 rounded-xl bg-pink-500/20 flex items-center justify-center mx-auto lg:mx-0">
                  <Star className="w-5 h-5 text-pink-400" />
                </div>
                <h4 className="font-bold text-white text-sm">Quality Products</h4>
                <p className="text-xs text-pink-100/70">Top-tier luxury cosmetics and virgin hair care.</p>
              </div>

              <div className="glass-card p-4 rounded-2xl border border-pink-500/20 space-y-2 text-center lg:text-left">
                <div className="w-10 h-10 rounded-xl bg-amber-400/20 flex items-center justify-center mx-auto lg:mx-0">
                  <Heart className="w-5 h-5 text-amber-300" />
                </div>
                <h4 className="font-bold text-white text-sm">Client Satisfaction</h4>
                <p className="text-xs text-pink-100/70">Guaranteed happiness with every transformation.</p>
              </div>
            </div>

            {/* Checkmark Features */}
            <div className="pt-2 flex flex-wrap items-center justify-center lg:justify-start gap-6 text-xs font-semibold text-pink-200">
              <span className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                HD Lace Melting Specialist
              </span>
              <span className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                Long-wear Sweat-Proof Makeup
              </span>
              <span className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                VIP House Calls Available
              </span>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
};
