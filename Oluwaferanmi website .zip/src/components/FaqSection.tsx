import React, { useState } from 'react';
import { FAQS_DATA } from '../data/beautyData';
import { Sparkles, ChevronDown, ChevronUp, HelpCircle } from 'lucide-react';

export const FaqSection: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const toggleAccordion = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section id="faq" className="py-20 lg:py-28 relative bg-[#0d0810]">
      <div className="absolute bottom-0 right-0 w-96 h-96 rounded-full bg-amber-500/10 blur-[150px] pointer-events-none"></div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center space-y-4 mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-pink-950/60 border border-pink-500/30 text-pink-200 text-xs font-semibold tracking-widest uppercase">
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>GOT QUESTIONS?</span>
          </div>

          <h2 className="text-3xl sm:text-5xl font-cinzel font-bold text-white tracking-tight">
            Frequently Asked <span className="gold-gradient-text">Questions</span>
          </h2>

          <p className="text-pink-100/70 text-sm sm:text-base">
            Everything you need to know about booking, appointments, home service, and wig drop-offs.
          </p>
        </div>

        {/* FAQ Accordion */}
        <div className="space-y-4">
          {FAQS_DATA.map((faq, index) => {
            const isOpen = openIndex === index;
            return (
              <div 
                key={index}
                className="glass-card rounded-2xl border border-pink-500/20 overflow-hidden transition-all"
              >
                <button
                  onClick={() => toggleAccordion(index)}
                  className="w-full p-6 text-left flex items-center justify-between gap-4 focus:outline-none"
                >
                  <div className="flex items-center gap-3">
                    <HelpCircle className="w-5 h-5 text-amber-300 shrink-0" />
                    <span className="font-bold text-white text-base sm:text-lg">{faq.question}</span>
                  </div>
                  <div className="w-8 h-8 rounded-full bg-pink-950/60 border border-pink-500/30 flex items-center justify-center text-pink-200 shrink-0">
                    {isOpen ? <ChevronUp className="w-4 h-4 text-amber-300" /> : <ChevronDown className="w-4 h-4" />}
                  </div>
                </button>

                {isOpen && (
                  <div className="px-6 pb-6 pt-2 text-sm text-pink-100/80 leading-relaxed border-t border-pink-950/40 animate-fadeIn">
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
