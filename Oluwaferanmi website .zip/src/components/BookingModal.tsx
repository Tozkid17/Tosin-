import React, { useState, useEffect } from 'react';
import { SERVICES_DATA } from '../data/beautyData';
import { Crown, Sparkles, X, Calendar, Clock, User, Phone, MapPin, CheckCircle2, ArrowRight, ArrowLeft } from 'lucide-react';
import confetti from 'canvas-confetti';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  preSelectedService?: string;
}

export const BookingModal: React.FC<BookingModalProps> = ({ isOpen, onClose, preSelectedService }) => {
  const [step, setStep] = useState<number>(1);
  const [selectedService, setSelectedService] = useState<string>('');
  const [serviceType, setServiceType] = useState<'studio' | 'home'>('studio');
  const [date, setDate] = useState<string>('');
  const [time, setTime] = useState<string>('10:00 AM');
  const [name, setName] = useState<string>('');
  const [phone, setPhone] = useState<string>('');
  const [notes, setNotes] = useState<string>('');
  const [isSuccess, setIsSuccess] = useState<boolean>(false);

  useEffect(() => {
    if (preSelectedService) {
      setSelectedService(preSelectedService);
    } else if (SERVICES_DATA.length > 0) {
      setSelectedService(SERVICES_DATA[0].title);
    }
  }, [preSelectedService]);

  if (!isOpen) return null;

  const handleCompleteBooking = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSuccess(true);
    
    // Trigger confetti
    try {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 }
      });
    } catch {
      // fallback
    }
  };

  const resetAndClose = () => {
    setStep(1);
    setIsSuccess(false);
    onClose();
  };

  const whatsappMessage = encodeURIComponent(
    `Hello Queen Oluwaferanmi! ✨\nI would like to book an appointment.\n\n*Service:* ${selectedService}\n*Location Type:* ${serviceType === 'studio' ? 'Studio Visit' : 'VIP Home Service'}\n*Date:* ${date}\n*Time:* ${time}\n*Name:* ${name}\n*Phone:* ${phone}\n*Notes:* ${notes}`
  );

  return (
    <div className="fixed inset-0 z-50 bg-[#0b070d]/90 backdrop-blur-xl flex items-center justify-center p-4 sm:p-6 overflow-y-auto animate-fadeIn">
      <div className="relative max-w-2xl w-full glass-card rounded-3xl overflow-hidden border border-pink-500/30 shadow-2xl my-8">
        
        {/* Modal Header */}
        <div className="p-6 sm:p-8 border-b border-pink-500/20 flex items-center justify-between bg-pink-950/40">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-amber-400 to-rose-500 flex items-center justify-center text-[#0b070d]">
              <Crown className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-xl font-cinzel font-bold text-white">Book Your Queen Session</h3>
              <p className="text-xs text-pink-300">Queen Oluwaferanmi Beauty Studio</p>
            </div>
          </div>

          <button
            onClick={resetAndClose}
            className="w-10 h-10 rounded-full bg-[#0b070d]/80 border border-pink-500/40 flex items-center justify-center text-pink-200 hover:text-amber-300 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Content */}
        <div className="p-6 sm:p-8">
          {isSuccess ? (
            <div className="text-center space-y-6 py-6 animate-fadeIn">
              <div className="w-20 h-20 rounded-full bg-emerald-500/20 border-2 border-emerald-400 flex items-center justify-center mx-auto text-emerald-400">
                <CheckCircle2 className="w-10 h-10" />
              </div>

              <div className="space-y-2">
                <h4 className="text-2xl font-cinzel font-bold text-white">Appointment Request Ready!</h4>
                <p className="text-sm text-pink-100/80 max-w-md mx-auto">
                  Your booking details have been successfully prepared. Click below to instantly send your appointment request via WhatsApp to Queen Oluwaferanmi at <span className="text-amber-300 font-bold">09168876667</span>.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-pink-950/40 border border-pink-500/20 text-left space-y-2 max-w-md mx-auto text-xs text-pink-200">
                <div><span className="text-pink-400 font-bold">Service:</span> {selectedService}</div>
                <div><span className="text-pink-400 font-bold">Date & Time:</span> {date || 'Selected Date'} at {time}</div>
                <div><span className="text-pink-400 font-bold">Location:</span> {serviceType === 'studio' ? 'Studio Visit' : 'VIP Home Service'}</div>
                <div><span className="text-pink-400 font-bold">Client Name:</span> {name || 'Valued Queen'}</div>
              </div>

              <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-4">
                <a
                  href={`https://wa.me/2349168876667?text=${whatsappMessage}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full sm:w-auto px-8 py-4 rounded-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs tracking-wider shadow-lg flex items-center justify-center gap-2 transition-all"
                >
                  <Sparkles className="w-4 h-4" />
                  SEND VIA WHATSAPP NOW
                </a>

                <button
                  onClick={resetAndClose}
                  className="w-full sm:w-auto px-6 py-4 rounded-full glass-card text-pink-200 text-xs font-semibold hover:border-pink-400 transition-all"
                >
                  Close & Return
                </button>
              </div>
            </div>
          ) : (
            <div>
              {/* Step indicator */}
              <div className="flex items-center justify-between mb-8 max-w-xs mx-auto text-xs font-bold">
                <div className={`flex items-center gap-1.5 ${step >= 1 ? 'text-amber-300' : 'text-pink-500/50'}`}>
                  <span className={`w-6 h-6 rounded-full flex items-center justify-center ${step >= 1 ? 'bg-amber-400 text-[#0b070d]' : 'bg-pink-950 text-pink-400'}`}>1</span>
                  <span>Service</span>
                </div>
                <div className={`w-8 h-[1px] ${step >= 2 ? 'bg-amber-400' : 'bg-pink-950'}`}></div>
                <div className={`flex items-center gap-1.5 ${step >= 2 ? 'text-amber-300' : 'text-pink-500/50'}`}>
                  <span className={`w-6 h-6 rounded-full flex items-center justify-center ${step >= 2 ? 'bg-amber-400 text-[#0b070d]' : 'bg-pink-950 text-pink-400'}`}>2</span>
                  <span>Date & Time</span>
                </div>
                <div className={`w-8 h-[1px] ${step >= 3 ? 'bg-amber-400' : 'bg-pink-950'}`}></div>
                <div className={`flex items-center gap-1.5 ${step >= 3 ? 'text-amber-300' : 'text-pink-500/50'}`}>
                  <span className={`w-6 h-6 rounded-full flex items-center justify-center ${step >= 3 ? 'bg-amber-400 text-[#0b070d]' : 'bg-pink-950 text-pink-400'}`}>3</span>
                  <span>Details</span>
                </div>
              </div>

              {/* Step 1: Service Selection */}
              {step === 1 && (
                <div className="space-y-6 animate-fadeIn">
                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase tracking-wider text-pink-300">Select Service</label>
                    <select
                      value={selectedService}
                      onChange={(e) => setSelectedService(e.target.value)}
                      className="w-full px-4 py-3.5 rounded-xl bg-pink-950/60 border border-pink-500/30 text-white text-sm focus:outline-none focus:border-amber-400"
                    >
                      {SERVICES_DATA.map((s) => (
                        <option key={s.id} value={s.title} className="bg-[#0b070d] text-white">
                          {s.title} ({s.price})
                        </option>
                      ))}
                      <option value="Custom VIP Package" className="bg-[#0b070d] text-white">Custom VIP Package</option>
                    </select>
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase tracking-wider text-pink-300">Location Preference</label>
                    <div className="grid grid-cols-2 gap-4">
                      <button
                        type="button"
                        onClick={() => setServiceType('studio')}
                        className={`p-4 rounded-xl border text-left transition-all ${
                          serviceType === 'studio'
                            ? 'bg-gradient-to-r from-rose-500/20 to-amber-500/20 border-amber-400 text-white'
                            : 'glass-card border-pink-500/20 text-pink-300'
                        }`}
                      >
                        <div className="font-bold text-sm">Studio Visit</div>
                        <div className="text-xs text-pink-300/70 mt-1">Queen&apos;s Luxury Studio</div>
                      </button>

                      <button
                        type="button"
                        onClick={() => setServiceType('home')}
                        className={`p-4 rounded-xl border text-left transition-all ${
                          serviceType === 'home'
                            ? 'bg-gradient-to-r from-rose-500/20 to-amber-500/20 border-amber-400 text-white'
                            : 'glass-card border-pink-500/20 text-pink-300'
                        }`}
                      >
                        <div className="font-bold text-sm">VIP Home Service</div>
                        <div className="text-xs text-pink-300/70 mt-1">We come to your location</div>
                      </button>
                    </div>
                  </div>

                  <div className="pt-4 flex justify-end">
                    <button
                      type="button"
                      onClick={() => setStep(2)}
                      className="px-8 py-3.5 rounded-full bg-gradient-to-r from-amber-400 via-rose-500 to-pink-500 text-[#0b070d] font-bold text-xs tracking-wider shadow-lg flex items-center gap-2 hover:scale-105 transition-transform"
                    >
                      <span>NEXT: DATE & TIME</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              )}

              {/* Step 2: Date & Time */}
              {step === 2 && (
                <div className="space-y-6 animate-fadeIn">
                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase tracking-wider text-pink-300 flex items-center gap-1.5">
                      <Calendar className="w-4 h-4 text-amber-300" />
                      Select Appointment Date
                    </label>
                    <input
                      type="date"
                      required
                      value={date}
                      onChange={(e) => setDate(e.target.value)}
                      className="w-full px-4 py-3.5 rounded-xl bg-pink-950/60 border border-pink-500/30 text-white text-sm focus:outline-none focus:border-amber-400"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase tracking-wider text-pink-300 flex items-center gap-1.5">
                      <Clock className="w-4 h-4 text-amber-300" />
                      Select Time Slot
                    </label>
                    <div className="grid grid-cols-3 gap-3">
                      {['09:00 AM', '11:30 AM', '02:00 PM', '04:30 PM', '06:00 PM'].map((t) => (
                        <button
                          key={t}
                          type="button"
                          onClick={() => setTime(t)}
                          className={`py-3 rounded-xl border text-xs font-bold transition-all ${
                            time === t
                              ? 'bg-gradient-to-r from-rose-500 to-amber-500 text-[#0b070d] border-amber-400 shadow-md'
                              : 'glass-card border-pink-500/20 text-pink-200'
                          }`}
                        >
                          {t}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="pt-4 flex justify-between items-center">
                    <button
                      type="button"
                      onClick={() => setStep(1)}
                      className="px-6 py-3.5 rounded-full glass-card text-pink-200 text-xs font-semibold hover:border-pink-400 transition-all flex items-center gap-2"
                    >
                      <ArrowLeft className="w-4 h-4" />
                      <span>Back</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setStep(3)}
                      className="px-8 py-3.5 rounded-full bg-gradient-to-r from-amber-400 via-rose-500 to-pink-500 text-[#0b070d] font-bold text-xs tracking-wider shadow-lg flex items-center gap-2 hover:scale-105 transition-transform"
                    >
                      <span>NEXT: YOUR DETAILS</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              )}

              {/* Step 3: Client Details */}
              {step === 3 && (
                <form onSubmit={handleCompleteBooking} className="space-y-6 animate-fadeIn">
                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase tracking-wider text-pink-300 flex items-center gap-1.5">
                      <User className="w-4 h-4 text-amber-300" />
                      Your Full Name
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Adebisi Adebayo"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full px-4 py-3.5 rounded-xl bg-pink-950/60 border border-pink-500/30 text-white text-sm focus:outline-none focus:border-amber-400 placeholder:text-pink-500/50"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase tracking-wider text-pink-300 flex items-center gap-1.5">
                      <Phone className="w-4 h-4 text-amber-300" />
                      Phone Number / WhatsApp
                    </label>
                    <input
                      type="tel"
                      required
                      placeholder="e.g. 08012345678"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full px-4 py-3.5 rounded-xl bg-pink-950/60 border border-pink-500/30 text-white text-sm focus:outline-none focus:border-amber-400 placeholder:text-pink-500/50"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase tracking-wider text-pink-300 flex items-center gap-1.5">
                      <MapPin className="w-4 h-4 text-amber-300" />
                      Additional Notes / Special Request
                    </label>
                    <textarea
                      rows={3}
                      placeholder="Tell us about your outfit, hair length, or event..."
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      className="w-full px-4 py-3 rounded-xl bg-pink-950/60 border border-pink-500/30 text-white text-sm focus:outline-none focus:border-amber-400 placeholder:text-pink-500/50 resize-none"
                    ></textarea>
                  </div>

                  <div className="pt-4 flex justify-between items-center">
                    <button
                      type="button"
                      onClick={() => setStep(2)}
                      className="px-6 py-3.5 rounded-full glass-card text-pink-200 text-xs font-semibold hover:border-pink-400 transition-all flex items-center gap-2"
                    >
                      <ArrowLeft className="w-4 h-4" />
                      <span>Back</span>
                    </button>

                    <button
                      type="submit"
                      className="px-8 py-3.5 rounded-full bg-gradient-to-r from-amber-400 via-rose-500 to-pink-500 text-[#0b070d] font-bold text-xs tracking-wider shadow-lg flex items-center gap-2 hover:scale-105 transition-transform"
                    >
                      <Sparkles className="w-4 h-4" />
                      <span>COMPLETE BOOKING</span>
                    </button>
                  </div>
                </form>
              )}

            </div>
          )}
        </div>

      </div>
    </div>
  );
};
