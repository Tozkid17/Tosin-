export interface ServiceItem {
  id: string;
  category: 'hair' | 'makeup' | 'combo';
  title: string;
  description: string;
  price: string;
  duration: string;
  image: string;
  popular?: boolean;
}

export interface PortfolioItem {
  id: string;
  title: string;
  category: 'bridal' | 'photoshoot' | 'hair' | 'soft-glam';
  image: string;
  description: string;
  tags: string[];
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  comment: string;
  rating: number;
  service: string;
  image: string;
}

export const SERVICES_DATA: ServiceItem[] = [
  {
    id: 'hair-1',
    category: 'hair',
    title: 'Wig Installation & Customization',
    description: 'Immaculate lace melting, plucking, bleaching knots, and styling for a seamlessly natural scalp appearance.',
    price: '₦25,000',
    duration: '1.5 - 2 hours',
    image: 'https://images.unsplash.com/photo-1560869713-7d0a29430803?auto=format&fit=crop&q=80&w=800',
    popular: true
  },
  {
    id: 'hair-2',
    category: 'hair',
    title: 'Luxury Hair Styling & Bounciness',
    description: 'Silk press, Hollywood waves, bone straight styling, or bouncy curls tailored to your outfit and event.',
    price: '₦15,000',
    duration: '45 mins - 1 hour',
    image: 'https://images.unsplash.com/photo-1519699047748-de8e457a634e?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'hair-3',
    category: 'hair',
    title: 'Braids & Protective Styles',
    description: 'Neat knotless braids, goddess braids, feed-in cornrows, and sleek protective styling that lasts.',
    price: '₦30,000+',
    duration: '3 - 5 hours',
    image: 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'hair-4',
    category: 'hair',
    title: 'Hair Treatment & Maintenance',
    description: 'Deep conditioning steam therapy, scalp detox, and restorative hydration for damaged or dry hair extensions/natural hair.',
    price: '₦18,000',
    duration: '1 hour',
    image: 'https://images.unsplash.com/photo-1527799820374-dcf8d9d4a388?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'makeup-1',
    category: 'makeup',
    title: 'Flawless Bridal Makeup',
    description: 'Bespoke royal bridal transformation including pre-wedding consultation, skin prep, lash application, and touch-up kit.',
    price: '₦75,000',
    duration: '2.5 hours',
    image: 'https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?auto=format&fit=crop&q=80&w=800',
    popular: true
  },
  {
    id: 'makeup-2',
    category: 'makeup',
    title: 'Photoshoot & Editorial Glam',
    description: 'High-definition, camera-ready makeup designed to capture every angle with perfect contour, strobe, and pigment.',
    price: '₦35,000',
    duration: '1.5 hours',
    image: 'https://images.unsplash.com/photo-1512496015851-a90fb38ba796?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'makeup-3',
    category: 'makeup',
    title: 'Soft & Natural Glam Look',
    description: 'The ultimate "enhance your features" beat. Subtle eyeshadow, glowing skin, feathered brows, and nude lips.',
    price: '₦20,000',
    duration: '1 hour',
    image: 'https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'makeup-4',
    category: 'makeup',
    title: 'Party & Occasion Full Glam',
    description: 'Turn heads at birthdays, anniversaries, owambes, and red carpet events with dramatic cut creases and glowing highlights.',
    price: '₦25,000',
    duration: '1 hour 15 mins',
    image: 'https://images.unsplash.com/photo-1516914943479-89db7d9ae7f2?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'combo-1',
    category: 'combo',
    title: 'The Ultimate Queen VIP Combo',
    description: 'Full luxury makeup application + Wig installation & custom styling. Walk out ready to rule your world!',
    price: '₦45,000',
    duration: '2.5 hours',
    image: 'https://images.unsplash.com/photo-1562322140-8baeececf3df?auto=format&fit=crop&q=80&w=800',
    popular: true
  }
];

export const PORTFOLIO_DATA: PortfolioItem[] = [
  {
    id: 'p-1',
    title: 'Royal Traditional Bride',
    category: 'bridal',
    image: 'https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&q=80&w=800',
    description: 'Traditional Yoruba bridal look featuring flawless warm skin finish, precision gele styling, and luxury bead coordination.',
    tags: ['Bridal', 'Traditional', 'Full Glam']
  },
  {
    id: 'p-2',
    title: 'Lace Melt & Bone Straight',
    category: 'hair',
    image: 'https://images.unsplash.com/photo-1560869713-7d0a29430803?auto=format&fit=crop&q=80&w=800',
    description: 'Custom HD lace frontal installation with bone straight Vietnamese hair and baby hair framing.',
    tags: ['Wig Install', 'Bone Straight', 'HD Lace']
  },
  {
    id: 'p-3',
    title: 'Editorial Neon Glow Shoot',
    category: 'photoshoot',
    image: 'https://images.unsplash.com/photo-1512496015851-a90fb38ba796?auto=format&fit=crop&q=80&w=800',
    description: 'High fashion editorial makeup with bold graphic eyeliner, glossy lips, and sleek high ponytail.',
    tags: ['Photoshoot', 'Editorial', 'Bold Glam']
  },
  {
    id: 'p-4',
    title: 'Soft Brown Everyday Beat',
    category: 'soft-glam',
    image: 'https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?auto=format&fit=crop&q=80&w=800',
    description: 'Flawless neutral eyeshadow tones, skin-like foundation finish, and fluffy brows for daytime luxury.',
    tags: ['Soft Glam', 'Natural Skin', 'Everyday']
  },
  {
    id: 'p-5',
    title: 'Hollywood Glam Curls',
    category: 'hair',
    image: 'https://images.unsplash.com/photo-1519699047748-de8e457a634e?auto=format&fit=crop&q=80&w=800',
    description: 'Deep side part voluminous retro curls for a red carpet ready red-carpet appearance.',
    tags: ['Hair Styling', 'Curls', 'Red Carpet']
  },
  {
    id: 'p-6',
    title: 'White Wedding Elegance',
    category: 'bridal',
    image: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=800',
    description: 'Timeless soft romantic white wedding makeup with subtle shimmer and long-wear airbrush finish.',
    tags: ['White Wedding', 'Bridal Glam', 'Classic']
  }
];

export const TESTIMONIALS_DATA: Testimonial[] = [
  {
    id: 't-1',
    name: 'Adebisi Adebayo',
    role: 'Bride & Entrepreneur',
    comment: 'Queen Oluwaferanmi transformed me for my traditional engagement! My makeup lasted over 14 hours through dancing and tears of joy without caking. Absolute perfection!',
    rating: 5,
    service: 'Flawless Bridal Makeup',
    image: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200'
  },
  {
    id: 't-2',
    name: 'Dr. Chiamaka Okafor',
    role: 'Medical Doctor',
    comment: 'Nobody melts lace like Queen! People thought my wig was literally my natural scalp. She is punctual, professional, and her studio vibe is so relaxing.',
    rating: 5,
    service: 'Wig Installation & Customization',
    image: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&q=80&w=200'
  },
  {
    id: 't-3',
    name: 'Folashade Adeleke',
    role: 'Fashion Model',
    comment: 'Working with Queen for my magazine shoot was a dream. She understands lighting, skin undertones, and brings out the absolute best in you. 10/10 recommended!',
    rating: 5,
    service: 'Photoshoot & Editorial Glam',
    image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&q=80&w=200'
  }
];

export const FAQS_DATA = [
  {
    question: 'How do I book an appointment with Queen Oluwaferanmi?',
    answer: 'You can easily book online using our booking wizard on this website or reach out directly via WhatsApp/Call at 09168876667. A 30% deposit is required to secure your preferred date and time slot.'
  },
  {
    question: 'Do you offer home service or mobile makeup/hair styling?',
    answer: 'Yes! We offer VIP home service / hotel house-calls for weddings, birthdays, and busy professionals. Additional travel fees apply based on your location.'
  },
  {
    question: 'How many days in advance should I drop off my wig for installation?',
    answer: 'For custom character styling, coloring, or customization (plucking & bleaching knots), please drop off your wig at least 48 hours prior to your appointment date.'
  },
  {
    question: 'What makeup brands and hair products do you use?',
    answer: 'We only use premium luxury and professional-grade products including Fenty Beauty, Charlotte Tilbury, NARS, MAC, Anastasia Beverly Hills, and high-grade virgin hair care treatments.'
  }
];
