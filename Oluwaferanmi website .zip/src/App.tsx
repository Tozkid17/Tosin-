import { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { ServicesSection } from './components/ServicesSection';
import { PortfolioSection } from './components/PortfolioSection';
import { AboutSection } from './components/AboutSection';
import { TestimonialsSection } from './components/TestimonialsSection';
import { FaqSection } from './components/FaqSection';
import { Footer } from './components/Footer';
import { BookingModal } from './components/BookingModal';
import { Phone, MessageCircle } from 'lucide-react';

export function App() {
  const [bookingModalOpen, setBookingModalOpen] = useState(false);
  const [preSelectedService, setPreSelectedService] = useState<string | undefined>(undefined);

  const handleOpenBooking = (serviceName?: string) => {
    if (serviceName) {
      setPreSelectedService(serviceName);
    } else {
      setPreSelectedService(undefined);
    }
    setBookingModalOpen(true);
  };

  const handleCloseBooking = () => {
    setBookingModalOpen(false);
  };

  return (
    <div className="min-h-screen bg-[#0b070d] text-[#f3e8ee] selection:bg-pink-500 selection:text-white relative">
      {/* Navbar */}
      <Navbar onOpenBooking={handleOpenBooking} />

      {/* Hero Section */}
      <Hero onOpenBooking={handleOpenBooking} />

      {/* Services & Pricing Section */}
      <ServicesSection onOpenBooking={handleOpenBooking} />

      {/* Portfolio Gallery Section */}
      <PortfolioSection onOpenBooking={handleOpenBooking} />

      {/* About Queen Oluwaferanmi Section */}
      <AboutSection />

      {/* Testimonials Section */}
      <TestimonialsSection />

      {/* FAQ Section */}
      <FaqSection />

      {/* Footer */}
      <Footer onOpenBooking={() => handleOpenBooking()} />

      {/* Booking Modal */}
      <BookingModal 
        isOpen={bookingModalOpen}
        onClose={handleCloseBooking}
        preSelectedService={preSelectedService}
      />

      {/* Floating Quick Action Buttons (WhatsApp & Call) */}
      <div className="fixed bottom-6 right-6 z-40 flex flex-col gap-3">
        <a
          href="https://wa.me/2349168876667"
          target="_blank"
          rel="noopener noreferrer"
          aria-label="Chat on WhatsApp"
          className="w-14 h-14 rounded-full bg-emerald-600 hover:bg-emerald-500 text-white flex items-center justify-center shadow-2xl shadow-emerald-950/80 hover:scale-110 transition-all group relative"
        >
          <MessageCircle className="w-7 h-7" />
          <span className="absolute right-full mr-3 px-3 py-1.5 rounded-xl bg-[#0b070d] border border-pink-500/30 text-white text-xs font-bold tracking-wider whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity shadow-lg pointer-events-none">
            Chat on WhatsApp
          </span>
        </a>

        <a
          href="tel:09168876667"
          aria-label="Call 09168876667"
          className="w-14 h-14 rounded-full bg-gradient-to-tr from-amber-400 to-rose-500 text-[#0b070d] flex items-center justify-center shadow-2xl shadow-pink-950/80 hover:scale-110 transition-all group relative"
        >
          <Phone className="w-6 h-6" />
          <span className="absolute right-full mr-3 px-3 py-1.5 rounded-xl bg-[#0b070d] border border-pink-500/30 text-white text-xs font-bold tracking-wider whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity shadow-lg pointer-events-none">
            Call 09168876667
          </span>
        </a>
      </div>
    </div>
  );
}

export default App;
